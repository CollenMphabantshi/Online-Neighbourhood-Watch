﻿
<?php
/*
$userna = $this->_request['username'];
$passwo = $this->_request['password'];
$platform = $this->_request['platform'];*/
/*
 $file_path = "uploads/";
     
    $file_path = $file_path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $file_path)) {*/

	
 class Aplus{
 	
 	public function __construct(){
 		$this->connect();
        
    }
 	
 	public function connect(){
 	
 		$user_name = "banchvyd_collen";
				$password = "Banchi007";
				$database = "banchvyd_aplus";
				$server = "localhost";
												
												
				$db_handle= mysqli_connect($server,$user_name ,$password,$database);
				if (mysqli_connect_errno())
					{
						echo 'Failed to connect to MySQL: ' . mysqli_connect_error();
					}
					else
					{
						echo "CONNECTION";
						
							/*$var=$_REQUEST["jsonstring"];
							$MyObj=json_decode($var);

							$firstname=$MyObj->name;
							$lname=$MyObj->surname;
							$id=$MyObj->identity;
							$email=$MyObj->email;
							$pass=$MyObj->password;
							$province=$MyObj->province;*/
							$filename=$_POST['filename'];
							$accidentType=$_POST['accidentType'];
							$province=$_POST['province'];
							$location=$_POST['location'];
							$date=$_POST['date'];
							$time=$_POST['time'];
							$cellnumber=$_POST['cellnumber'];
							$serialnumber=$_POST['serialnumber'];
							$deviceId=$_POST['deviceId'];
							$temperature=$_POST['temperature'];
							
						
							$connected = mysqli_query($db_handle,"INSERT INTO banchvyd_aplus.accident(filename,accidentType,province,location,date,time,cellnumber,serialnumber,deviceId,temperature)  VALUES('".$filename."','".$accidentType."','".$province."','".$location."','".$date."','".$time."','".$cellnumber."','".$serialnumber."','".$deviceId."','".$temperature."')");
	
							$response = array();
							$response["success"] = "Yeah success";
						    	$response["message"] = "the response works";
						    	echo json_encode($response);
							
							
						}
			
		
	        echo "success";
			mysql_close($db_handle);
 	
 	}
 
 }
				
		$obj = new Aplus();
		//$obj ->connect();

	
?>