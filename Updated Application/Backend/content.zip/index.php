<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title> BanchiTech Coming Soon</title>
    <style>
	* {
	  padding: 20;
	  margin: 20;
	}
	.fit {
	  max-width: 110%;
	  max-height: 110%;
	}
	.center {
	  display: block;
	  margin: auto;
	}
	</style>
   
</head>

<body>
	<h1 align="center">Coming Soon</h1>
	<div align="center">
		<img src="splashlogo.png" class=".fit center" alt="BanchiTech">
		<br/>
		<h1> Powered by:</h1>
		<br/>
            <img src="logo.png" class=".fit center" alt="BanchiTech">
    	</div>
</body>
</html>