<?php

    function hashpass($pass) {
        $salt = "jZ15R7#Qq1eJaX1xU&";
        
        return hash("SHA256", $pass.$salt);
    }
    function isAuthenticated($user,$pass) {
        $con = mysql_connect("localhost", "banchvyd_collen", "Banchi007");
        mysql_select_db("banchvyd_uwatch");
        
        $res = mysql_query("select * from users where email='$user' and password='$pass'");
        if(mysql_num_rows($res) > 0){
            return TRUE;
        }
        
        return FALSE;
    }
    
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(isAuthenticated($username,hashpass($username.$password)))
	{
		die("Success: access granted.");
	}else{
		die("Error: access denied. username or password is incorrect.");
	}
?>