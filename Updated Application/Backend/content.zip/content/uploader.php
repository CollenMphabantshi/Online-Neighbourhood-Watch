<?php
function hash_matched($param1,$param2) {
    $server_hash = hash_file("sha256", $param1,FALSE);
    if($server_hash !== $param2)
    {
        unlink($param1);
        return FALSE;
    }else{
        return TRUE;
    }
}

function response($param) {
    die($param);
}

function addToDatabase($path,$hash,$user,$caseType,$caseLocation) {
    $con = mysql_connect("localhost", "banchvyd_collen", "Banchi007");
        mysql_select_db("banchvyd_uwatch");
    return mysql_query("insert into watchdata values(0,'$path','$hash','$user','$caseType','$caseLocation')");
}

function sendMail($email,$message)
{
	$to = $email;
	$subject = "Neighborhood Watch Notification";

	$cmessage = "
	<html>
	<head>
	<title>".$subject."</title>
	</head>
	<body>
	<p><b>This email contains notifications from the UWatch app.</b></p>
	<div>
		".$message."
	</div>
	</body>
	</html>
	";

	// Content-type of email
	$headers = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	// More headers
	$headers .= 'From: <do-not-reply@tuks.co.za>' . "\r\n";
	
	ini_set('SMTP','kendy.up.ac.za');
	mail($to,$subject,$cmessage,$headers);
}


$target_path = "";
$all_clear = FALSE;
$res = "";
$target_path = time().'_'.basename( $_FILES['capturedfile']['name']);

if(move_uploaded_file($_FILES['capturedfile']['tmp_name'], $target_path)) {
    $res .= "The file ".  basename( $_FILES['capturedfile']['name']).
    " has been uploaded\n";
    
    $all_clear = hash_matched($target_path,$_POST['hash']);
}
else{
    $res .= "There was an error uploading the image file, please try again!\n";
}

if($all_clear ===  FALSE)
{
    response("The data sent was modified. Please send only video, image, or audio that was not modified.");
    response($res);
    
}else{
    if(addToDatabase($target_path,$_POST['hash'],$_POST['username'],$_POST['caseType'],$_POST['caseLocation']))
    {
	//sendMail($_POST['username'],'You have uploaded this file: '.$target_path.'<br/> with a hash: '.$_POST['hash']);
        response($res);
    }else{
        response("Failed to add data to the database.".$_POST['hash']);
    }
}

?>