<?php

    function response($status,$message) {
        $arr = array();
        $arr['status'] = $status;
        $arr['msg'] = $message;
        die(json_encode($arr));
    }
    function hashpass($pass) {
       $salt = "jZ15R7#Qq1eJaX1xU&";

        return hash("SHA256", $pass.$salt);
    }
    function isRegistered($user,$id) {
        $con = mysql_connect("localhost", "banchvyd_collen", "Banchi007");
        mysql_select_db("banchvyd_uwatch");
        
        $res = mysql_query("select * from users where email='$user' or identity='$id'");
        
        if($res !== FALSE)
        {
            if(mysql_num_rows($res) > 0){
                return TRUE;
            }else{
                return FALSE;
            }
        }
        return TRUE;
    }
    
   function register($name,$surname,$identity,$email,$password,$province) {
	$con = mysql_connect("localhost", "root", "");
        mysql_select_db("uwatch");
	$password = hashpass($email.$password);
	return mysql_query("insert into users values(0,'$name','$surname','$identity'
	,'$email','$password','$province','Normal')");
    }
    
	$name = $_POST['name'];
	$surname = $_POST['surname'];
	$identity = $_POST['identity'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$province = $_POST['province'];
	
	if($name != "" && $surname != "" && $identity != "" 
	&& $email != "" && $password != "" && $province != "")
	{
		if(!isRegistered($email,$identity))
		{
			if(register($name,$surname,$identity,$email
			,$password,$province))
			{
				response("Success","Account was created.");
			}else{
				response("Error","Failed to create account.");
			}
		}else{
			response("Error","Failed to create account, the email or identity already registered.");
		}
	}else{
		response("Error", "Failed to create account, fill in all fields.");
	}
?>